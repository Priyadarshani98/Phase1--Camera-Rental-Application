package com.cameraRental.main;

import com.cameraRental.login.Login; 
public class CameraRentalEx { 
public static void main(String[] args) { 
 // TODO Auto-generated method stub
 Login login = new Login(); 
 login.userLogin(); 
}

}
